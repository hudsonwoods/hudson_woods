---
previewImage: '{{ _site_root }}assets/img/upgrades/fruit-tree-thumbnail.jpg'
title: Fruit Tree Grove
specs:
  - 
    text: 'Large Grove:'
  - 
    text: 30 five-year-old fruit trees selected by a master gardener
  - 
    text: Includes 3 months of initial maintenance
  - 
    text: 'Small Grove:'
  - 
    text: 10 five-year-old fruit trees selected by a master gardener
  - 
    text: Includes 3 months of initial maintenance
  - 
    text: Tree species may include chestnut, black walnut, hazelnut, mulberry, apple, cherry, pear, peach
categories:
  - land
cost: Small $4,000 / Large $10,500
specDownload: '{{ _site_root }}assets/img/upgrades/Land Upgrades-20140724000225.pdf'
imageSingle: '{{ _site_root }}assets/img/homes/Fruit-grove-Details-image.jpg'
---
<p>$10,500</p>