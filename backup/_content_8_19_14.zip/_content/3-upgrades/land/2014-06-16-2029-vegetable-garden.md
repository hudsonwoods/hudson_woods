---
previewImage: '{{ _site_root }}assets/img/upgrades/veg-garden-thumbnail.jpg'
title: Vegetable Garden
specs:
  - 
    text: 'Large Garden:'
  - 
    text: 8 large (4’ x 8’) raised garden beds
  - 
    text: Approximately 100 vegetable and herb plants selected by a master gardener
  - 
    text: Includes 3 months of initial maintenance
  - 
    text: 'Small Garden:'
  - 
    text: 4 small (3’ x 4’) raised garden beds
  - 
    text: Approximately 40 vegetable and herb plants selected by a master gardener
  - 
    text: Includes 3 months of initial maintenance
  - 
    text: Vegetable and herb species may include tomato, eggplant, pepper, lettuces, cabbage, bok choy, beet, onion, garlic, carrot, potato, broccoli, collard greens, swiss chard, radish, cucumber, corn, beans, summer squash, winter squash, basil, dill, oregano, thyme, cilantro, blueberry, raspberry, currant
categories:
  - land
cost: Small $7,000 / Large $14,000
specDownload: '{{ _site_root }}assets/img/upgrades/Land Upgrades-20140724000233.pdf'
imageSingle: '{{ _site_root }}assets/img/homes/Vegetable-Details-image.jpg'
---
<p>$14,000</p>