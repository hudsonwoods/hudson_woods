---
title: Windows and Doors
categories:
  - house
specs:
  - 
    text: Mahogany-framed, hinged insect screens at all operable windows and doors
  - 
    text: Oil rubbed bronze hardware
previewImage: '{{ _site_root }}assets/img/upgrades/Window-screen-Thumbnail.jpg'
cost: $7,500
specDownload: '{{ _site_root }}assets/img/upgrades/detail upgrades-20140724000009.pdf'
imageSingle: '{{ _site_root }}assets/img/homes/3-20140727020929.jpg'
---
<p>$7,500</p>