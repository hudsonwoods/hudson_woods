---
title: Stain for Wood Floor
categories:
  - house
specs:
  - 
    text: Walnut-colored oil finish on wood floors through house
previewImage: '{{ _site_root }}assets/img/upgrades/Oak.jpg'
cost: $2,500
specDownload: '{{ _site_root }}assets/img/upgrades/detail upgrades-20140723235948.pdf'
imageSingle: '{{ _site_root }}assets/img/homes/2-20140727020951.jpg'
---
<p>$2,500</p>