---
title: Copper Roofing
categories:
  - house
specs:
  - 
    text: Standing seam copper roofing
  - 
    text: 'Note: copper will patina with age'
previewImage: '{{ _site_root }}assets/img/upgrades/copper.jpg'
cost: $40,000
specDownload: '{{ _site_root }}assets/img/upgrades/detail upgrades.pdf'
imageSingle: '{{ _site_root }}assets/img/homes/1-20140727021006.jpg'
---
<p>$40,000</p>