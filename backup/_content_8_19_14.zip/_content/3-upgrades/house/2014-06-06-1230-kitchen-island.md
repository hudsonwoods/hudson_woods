---
title: Kitchen Island
categories:
  - house
specs:
  - 
    text: Freestanding island built by local furniture company Sawkille Co.
  - 
    text: Built from blackened steel with solid black walnut drawers and soapstone countertop
  - 
    text: Drawer dividers with integral knife block and customizable peg system in large drawer
previewImage: '{{ _site_root }}assets/img/upgrades/Kitchen-Island-Thumbnail-20140709143017.jpg'
imageGallery:
  - 
    image: '{{ _site_root }}assets/img/homes/4-20140727020354.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/1-20140727020354.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/2-20140727020354.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/3-20140727020354.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/5-20140727020354.jpg'
cost: $17,000
specDownload: '{{ _site_root }}assets/img/upgrades/island.pdf'
---
<p>$17,000</p>