---
previewImage: '{{ _site_root }}assets/img/upgrades/kitchen-pantry-thumbnail.jpg'
title: Kitchen Pantry
specs:
  - 
    text: 'Built from solid black walnut with hand-rubbed oil finish and soapstone counter	'
  - 
    text: Custom in-laid brass details and leather door pulls
  - 
    text: Integrated electrical outlets
  - 
    text: 'Storage for small appliances '
imageGallery:
  - 
    image: '{{ _site_root }}assets/img/homes/Pantry1.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/Pantry2.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/Pantry3.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/Pantry4.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/Pantry5.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/Pantry6.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/Pantry8.jpg'
categories:
  - house
cost: $18,000
specDownload: '{{ _site_root }}assets/img/upgrades/pantry.pdf'
---
<p>$18,000</p>