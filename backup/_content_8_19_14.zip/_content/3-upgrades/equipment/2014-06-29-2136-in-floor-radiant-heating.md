---
previewImage: '{{ _site_root }}assets/img/upgrades/in-floor-thumbnails.jpg'
title: In-Floor Radiant Heating
specs:
  - 
    text: Provides comfortable even heat with a gently warmed floor surface
imageGallery:
  - 
    image: '{{ _site_root }}assets/img/homes/in-floor-thumbnails.jpg'
categories:
  - equipment
cost: 'Lower Level Only $7,000 / Full House - $16,500'
specDownload: '{{ _site_root }}assets/img/upgrades/Equipment-20140723235720.pdf'
---
