---
previewImage: '{{ _site_root }}assets/img/upgrades/Untitled-1.gif'
title: Porch / Outdoor Kitchen
categories:
  - site
specs:
  - 
    text: 400 sf
  - 
    text: Cedar framed screened porch pavilion
  - 
    text: Outdoor kitchen with stainless steel propane/charcoal hybrid grill, under counter refrigerator and cabinetry by Kalamazoo Outdoor Gourmet
  - 
    text: Concrete countertop
imageGallery:
  - 
    image: '{{ _site_root }}assets/img/homes/1-20140727173846.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/2-20140727173846.jpg'
  - 
    image: '{{ _site_root }}assets/img/homes/3-20140727173846.jpg'
cost: $100,000
specDownload: '{{ _site_root }}assets/img/upgrades/Porch_Outdoor Kitchen.pdf'
---
<p>$100,000</p>