---
title: 'From the Source: Sun Valley Bronze'
author: HudsonWoods
categories:
  - architecture
  - craftsmanship
  - materials
contentSummary: |
  <p>Last week we looked at a detail element of building the Hudson Woods model home with window and door framing provided by Premier Custom Millwork. This week we're focusing on another detail element - the door&nbsp;hardware used around the home. This has been element that truly makes a difference and one that most people have noticed and commented on when visiting the model home.&nbsp;</p><p>Marc Cervarich of Sun Valley Bronze, said it best, "Sometimes builders, architects, and designers don’t see or really appreciate the hardware and don't think it makes much of a difference. Hudson Woods does and appreciates the difference hardware makes compared to others. Quality, finish, warranty, service, and made in the USA was something they would not part with and as you can see in the end result of the home, it’s beautiful and first class."</p><p>We partnered with Sun Valley to install&nbsp;sand cast solid bronze door handles throughout the home. They are made using a traditional&nbsp;artisanal&nbsp;technique and produced in small batches by request. You can sense the design with every open and close of a door.&nbsp;</p>
---
