---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_ski_windham.jpg'
title: Windham Mountain
activity: Ski
---
<p><span>Windham Mountain is located in the northern section of the Catskills . It has 46 trails and 9 lifts, including two high-speed detachable quads, one from the bottom to top of each peak. The highest peak is situated at 3,100 feet (940 m). </span></p><p><a href="http://www.windhammountain.com/" target="_blank">windhammountain.com</a></p>