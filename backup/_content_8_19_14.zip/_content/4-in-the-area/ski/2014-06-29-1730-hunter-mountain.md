---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_ski_hunter.jpg'
title: Hunter Mountain
activity: Ski
---
<p><span>Hunter Mountain offers snow tubing and snowshoeing as well skiing. Hunter Mountain also features two terrain parks and holds freestyle events throughout the ski season.</span></p><p><a href="http://www.huntermtn.com/" target="_blank">huntermtn.com</a></p>