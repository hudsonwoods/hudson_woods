---
title: Mountain Trails XC Ski Center
activity: ski
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SKI_Trails.jpg'
---
<p>The&nbsp;300 acres of&nbsp;gorgeous Catskill park has&nbsp;22 miles of former logging roads have been upgraded and are continually groomed&nbsp;and re-graded. Fear not if you are un-initiated to alpine skiing&nbsp;since all necessities for skiing (or snowshoeing) can be rented or purchased at the lodge</p><p><a href="http://www.mtntrails.com/home.html" target="_blank">mtntrails.com</a></p>