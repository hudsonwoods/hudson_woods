---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_PICK&GROW_Olana.jpg'
title: The Olana Estate
activity: Culture
---
<p>Former home of&nbsp;Frederic Edwin Church, a&nbsp;Hudson River landscape painter&nbsp;this&nbsp;grand,&nbsp;eccentric mansion is a&nbsp;mixture of Victorian, Persian and Moorish style. It&nbsp;is lavishly accoutered with objects from Church's&nbsp;extensive travels and&nbsp;contains over 40 of his paintings.</p><p><a href="http://www.olana.org/" target="_blank">olana.org</a></p>