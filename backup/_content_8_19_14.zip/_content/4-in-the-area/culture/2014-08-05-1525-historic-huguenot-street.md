---
title: Historic Huguenot Street
activity: culture
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_CULTURE_Hugenot.jpg'
---
<p>Beautifully preserved and maintained by descendants of the Huguenots who in 1678 began this&nbsp;community.&nbsp;Historic Huguenot Street is fabulous collection of stone homes, churches and meeting places of various colonial styles. With names like Bevier, Hasbrouk, Walloon and&nbsp;Freer on tombstones and plaques.</p><p><a href="http://www.huguenotstreet.org/" target="_blank">huguenotstreet.org</a></p>