---
title: Woodstock Playhouse
activity: culture
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_CULTURE_playhouse.jpg'
---
<p>As a "rural extension of Broadway," the Playhouse mounts traveling versions of famous musicals and summer repertory performances. The docket is also chock full of films, musical events and local theater.&nbsp;</p><p><a href="http://www.woodstockplayhouse.org/" target="_blank">woodstockplayhouse.org</a></p>