---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SIP_Bacchus.jpg'
title: The Brewery at Bacchus
activity: Sip
---
<p>The 2 year-old&nbsp;Brewery at Bacchus operates as a&nbsp;series of experiments with unusual beers categories:&nbsp;Brett saisons, farmhouse ales aged on fruit, dark sours, 100% Brett IPAs, whiskey-aged imperial stouts. Because it's such a small operation, there is limited&nbsp;production and each barrel goes quickly.</p><p><a href="http://www.bacchusnewpaltz.com/brewery">http://www.bacchusnewpaltz.com/brewery</a></p>