---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_sip_tuthill.jpg'
title: 'Tuthilltown Spirits '
activity: Sip
---
<p>The adorable but pricey family of&nbsp;Hudson&nbsp;Whiskeys as well as Half Moon&nbsp;Orchard Gin, Indigenous Vodkas and evan a Cassis are all&nbsp;distilled from locally grown grains, apples and corn. Take a tour, hit the store, and have lunch or dinner next door&nbsp;at the historic grist mill turned restaurant.&nbsp;</p><p><a href="http://www.tuthilltown.com/" target="_blank">tuthilltown.com</a></p>