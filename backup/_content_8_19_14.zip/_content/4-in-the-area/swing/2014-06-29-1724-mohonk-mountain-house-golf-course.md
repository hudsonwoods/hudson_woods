---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWING_Mohonk.jpg'
title: 'Mohonk Mountain House Golf Course '
activity: Swing
---
<p>The nine holes are set among the mountain terrain of the Shawangunk Ridge, and so playing here is a bit like riding a roller coaster. Each hole is&nbsp;on a small foot print with limited sight lines, and yet it's still&nbsp;very fun to play while giving you quite the workout if you choose to walk it. Public course and&nbsp;available to non-guests.</p><p><a href="http://www.mohonk.com/activities/overnight/outdoors#Golf" target="_blank">mohonk.com/activities/overnight/outdoors#Golf</a></p>