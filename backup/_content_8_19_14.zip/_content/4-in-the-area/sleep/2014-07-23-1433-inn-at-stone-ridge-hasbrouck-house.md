---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SLEEP_Hasbrouck.jpg'
title: Hasbrouck House
activity: Sleep
---
<p>This 18th century&nbsp;mansion,&nbsp;built by the prominent Dutch&nbsp;Hasbrouck family&nbsp;has been continuously occupied. It&nbsp;currently serves&nbsp;as a bed & breakfast with each room reflecting different periods of the Hasbrouck family with fully updated modern amenities. It is on&nbsp;45 acres of groomed lawns and&nbsp;beautiful&nbsp;gardens.</p><p><a href="http://www.innatstoneridge.com/" target="_blank">innatstoneridge.com</a></p>