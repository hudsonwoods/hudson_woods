---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SLEEP_Mohonk.jpg'
title: Mohonk Mountain House
activity: Sleep
heroImages:
  - 
    image: '{{ _site_root }}assets/img/upgrades/Card-Icon-sleep.png'
    headline: ""
    subHeadline: ""
---
<p>The grand dame of Hudson Valley resorts (and longest surviving), the enormous&nbsp;Mountain House is perched in one of the most memorable settings in the country. The fairly new spa comes highly recommended&nbsp;and the&nbsp;dated nine-hole golf course set in a mountain is a wild pitch and putt. Skating in the winter is perfect and the grounds are brilliantly gardened.&nbsp;<a href="http://www.mohonk.com/">mohonk.com</a></p>