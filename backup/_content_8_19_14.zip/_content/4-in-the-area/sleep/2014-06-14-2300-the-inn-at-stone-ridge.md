---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SLEEP_Stone-ridge.jpg'
title: The Inn at Stone Ridge
activity: Sleep
---
<p>This 18th century mansion, built by the prominent Dutch Hasbrouck family has been continuously occupied. It currently serves as a bed & breakfast with each room reflecting different periods of the Hasbrouck family with fully updated modern amenities. It is on 45 acres of groomed lawns and beautiful gardens.&nbsp;<a href="http://www.innatstoneridge.com/">innatstoneridge.com</a></p><p><a href="http://www.innatstoneridge.com/" target="_blank"></a></p>