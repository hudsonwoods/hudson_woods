---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SLEEP_Graham.jpg'
title: 'The Graham & Co'
activity: Sleep
---
<p>The side project of 4 enterprising Brooklynites working in the realms of fashion and design, the Graham & Co is a cool&nbsp;mix of&nbsp;mid-century modern and quaint American rustic-chic.&nbsp;Camp-like features include outdoor movie nights, a fire pit, inner tubes in the pool&nbsp;and a&nbsp;rustic bar. Their 20 rooms are&nbsp;very popular among the twee, so book early!&nbsp;<a href="http://thegrahamandco.com/">thegrahamandco.com</a></p>