---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_sleep_elmrock.jpg'
title: 'Elmrock Inn Bed & Breakfast'
activity: Sleep
---
<p>A&nbsp;1770 Dutch Boutique-Style Farmhouse offering guest accommodations and often hosting weddings for locals an out of towers. Apparently the catering is superb...<br><br><a href="http://elmrockinn.com/" target="_blank">elmrockinn.com</a></p>