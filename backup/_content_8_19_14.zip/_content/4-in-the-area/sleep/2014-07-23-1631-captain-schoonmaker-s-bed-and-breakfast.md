---
title: "Captain Schoonmaker's Bed & Breakfast"
activity: Sleep
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SLEEP_Captain.jpg'
---
<p>Captain Frederick Schoonmaker was a local Civil War hero. Of his large estate,&nbsp;only the stone&nbsp;house remained in his name when the war ended. For the past 30 years, it has been a well known bed & breakfast with&nbsp;quaint charm.&nbsp;<a href="http://www.captainschoonmakers.com/">www.captainschoonmakers.com</a></p>