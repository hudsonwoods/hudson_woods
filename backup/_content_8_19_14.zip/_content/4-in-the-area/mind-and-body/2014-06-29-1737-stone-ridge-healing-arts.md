---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_MIND&BODY_Healing-center.jpg'
title: 'Stone Ridge Healing Arts	'
activity: 'Mind & Body'
---
<p>The&nbsp;facility features&nbsp;several practitioners of "healing" methods from meditation to nutrition and&nbsp;counseling. Also notable is the building itself is a&nbsp;Dutch&nbsp;stone farmhouse dated from&nbsp;1753 which has been&nbsp;re-imagined to be more contemporary.</p><p><a href="http://stoneridgehealingarts.com" style="background-color: initial;">http://stoneridgehealingarts.com</a></p>