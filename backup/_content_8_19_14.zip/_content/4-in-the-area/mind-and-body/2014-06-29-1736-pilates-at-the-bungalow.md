---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_mindandbody_bungalow.jpg'
title: Pilates at the Bungalow
activity: 'Mind & Body'
---
<p>All the equipment, expertise and rigor of the Joseph Pilates method&nbsp;in a scenic setting just 9 minutes from Hudson Woods. This beautiful studio has been voted best pilates studio in the Hudson Valley by Hudson Valley Magazine.&nbsp;</p><p><a href="http://www.pilatesatthebungalow.com/Pilates/Home.html"></a></p><p><a href="http://www.pilatesatthebungalow.com/" target="_blank">pilatesatthebungalow.com</a></p>