---
title: The Bear Café, Woodstock
activity: eat
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Bear.jpg'
---
<p>On the&nbsp;banks of the Saw Kill (river) and adjacent the Bearsville theater, the Bear Café is as Woodstock as it gets. It opened in 1971 by&nbsp;then manager of Bob Dylan, the Band,&nbsp;Janis Joplin and many&nbsp;others. The crowd is there to&nbsp;"see-and-be-seen" and to enjoy the emphasis on&nbsp;organic&nbsp;ingredients on the&nbsp;"big city-class" menu.</p><p><a href="http://www.bearcafe.com/" target="_blank">bearcafe.com</a></p>