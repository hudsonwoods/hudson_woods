---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_eat_country.jpg'
title: The Country Inn
activity: Eat
---
<p>Wait, are we in Williamsburg? This former biker bar has brief but considered menu, over 400 beers from around the world, a beautiful deck with a lake view and plenty of taxidermy. They have recently installed a pizza oven as well. Here come more hipsters&hellip; beat them before kitchen closes at 9.</p><p><a href="http://krumville.com/" target="_blank">krumville.com/</a></p>