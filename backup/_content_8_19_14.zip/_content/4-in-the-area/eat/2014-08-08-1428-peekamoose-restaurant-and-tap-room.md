---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Peekamoose-20140808155744.jpg'
title: 'Peekamoose Restaurant & Tap Room'
activity: eat
---
<p>This restaurant has lots going for it: Chef Devin Mills is from Brooklyn;&nbsp;he and his wife&nbsp;trained at Le Bernardin,&nbsp;Gramercy Tavern and&nbsp;Picholine among others; 35 beers are on tap; ingredients are&nbsp;sourced from local growers;&nbsp;the prices are reasonable;&nbsp;it's got "lodge appeal"</p><p><a href="http://www.peekamooserestaurant.com/" target="_blank">peekamooserestaurant.com</a></p>