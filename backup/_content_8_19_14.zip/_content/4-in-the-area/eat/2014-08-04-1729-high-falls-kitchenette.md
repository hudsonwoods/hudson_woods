---
title: High Falls Kitchenette
activity: eat
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Kitchenette.jpg'
---
<p>This retro-adorable eatery serves rather decadent comfort food, shakes, pies and most notably, a lavish country breakfast. A&nbsp;High Falls version of the popular locations in Manhattan. Mom will be jealous.</p><p><a href="http://www.kitchenetterestaurant.com/home.html" target="_blank">www.kitchenetterestaurant.com</a></p>