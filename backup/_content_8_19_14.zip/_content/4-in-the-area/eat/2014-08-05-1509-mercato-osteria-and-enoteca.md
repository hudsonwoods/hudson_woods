---
title: 'Mercato Osteria & Enoteca'
activity: eat
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Mercato.jpg'
---
<p>This authentic Italian osteria serves very upscale food to the dining cognoscenti on both sides of the Hudson. Co-owner Francesco Buitoni is in fact a 7th&nbsp;generation member of the Buitoni pasta family and according to the Times, the restaurant&nbsp;"enables him to cook the way he grew up eating in Italy."</p><p><a href="http://www.mercatoredhook.com/" target="_blank">mercatoredhook.com</a></p>