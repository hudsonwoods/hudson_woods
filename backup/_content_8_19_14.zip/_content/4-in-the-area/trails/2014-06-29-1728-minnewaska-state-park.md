---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_trails_minnewaska.jpg'
title: Minnewaska State Park
activity: Trails
---
<p>At 21,106 acres and occupying part of&nbsp;New Paltz, Gardiner and&nbsp;Ellenville, the Minnewaska State Park Preserve is a behemoth size wise, but is also amenable to all levels of hikers,&nbsp;walkers,&nbsp;bikers, horses and XC skiing.&nbsp;Along with its two famous lakes Awosting and Minnewaska, the park contains a bey of fun destinations.</p><p><a href="http://nysparks.com/parks/127/details.aspx" target="_blank">http://nysparks.com/parks/127/details.aspx</a></p>