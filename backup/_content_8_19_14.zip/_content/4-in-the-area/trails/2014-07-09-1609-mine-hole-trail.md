---
title: Mine Hole Trail
activity: Trails
heroImages:
  - 
    image: '{{ _site_root }}assets/img/upgrades/Card-Icon-trail.png'
    headline: ""
    subHeadline: ""
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_TRAILS_Minehole.jpg'
---
<p>The recently opened 3.5 mile trail now connects the Shawangunks to the Catskills. Access from&nbsp;inside the Minnewaska State Park.&nbsp;</p><p><a href="http://www.nynjtc.org/mine-hole-trail" target="_blank">nynjtc.org/mine-hole-trail</a></p>