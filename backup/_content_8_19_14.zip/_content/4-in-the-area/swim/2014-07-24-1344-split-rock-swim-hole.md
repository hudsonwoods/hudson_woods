---
title: Split Rock Swim Hole
activity: Swim
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWIM_splitrock.jpg'
---
<p>Split Rock Hole is a collection&nbsp;of unique&nbsp;wading opportunities. A&nbsp;brisk stream between two sizable cliffs&nbsp;where jumping off is a popular option.&nbsp;Take 44/55 to Clove Rd. Keep to the right on this dirt road, over bridges, until you get to the to the Coxing Kill Trailhead and parking area. Requires Mohonk Preserve Day Pass $10.</p><p><a href="http://www.mohonkpreserve.org/coxing-trailhead" target="_blank">mohonkpreserve.org/coxing-trailhead</a></p>