---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWIM_Stonykill.jpg'
title: Stony Kill Falls
activity: Swim
---
<p>The reward for a&nbsp;relatively brief walk in a portion of the&nbsp;Minnewaska Park, near&nbsp;Wawarsing&nbsp;is a stunning 90 foot waterfall flowing&nbsp;over a sheer cliff face into a&nbsp;pristine swimming hole. Above the fall is a pool from which&nbsp;there are&nbsp;marvelous views of the&nbsp;Stony Creek and Roundout Valleys, into Sullivan County.</p><p><a href="http://nysparks.com/parks/127/details.aspx" target="_blank">nysparks.com</a>  &nbsp;<a href="http://en.wikipedia.org/wiki/Stony_Kill_Falls" target="_blank" style="background-color: initial;">Wikipedia</a></p>