---
title: Hudson Valley Farm Hub
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Farmhub.jpg'
activity: Pick And Grow
---
<p>The Farm Hub is an experimental farming model that aims to be a regional center for farmer training, agricultural research and for incubating innovative farm technologies. Visit the farm stand in Hurley dedicated to building a resilient food system.&nbsp;</p><p><a href="http://www.localeconomiesproject.org/initiatives/farm-hub/">http://www.localeconomiesproject.org/initiatives/f...</a></p>