---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Seeds.jpg'
title: Hudson Valley Seed Library
activity: 'Pick & Grow'
---
<p>What was once a side project for a librarian in nearby Gardiner is now a three acre facility that produces 100's of pounds of seeds each year. Seeds are&nbsp;grown on site or sourced from local farms and all certified Organic.&nbsp;</p><p><a href="http://www.seedlibrary.org/" target="_blank">seedlibrary.org</a></p>