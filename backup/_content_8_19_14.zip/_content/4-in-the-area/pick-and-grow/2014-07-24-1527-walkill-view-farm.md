---
title: Walkill View Farm
activity: 'Pick & Grow'
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Walkill.jpg'
---
<p>Possibly the best reason to visit this amazing farmer's market is to soak in the views. Plunked in the middle of a&nbsp;hundred acres&nbsp;of fields, the market is&nbsp;backgrounded by the Shawangunk escarpment. There is a&nbsp;huge variety of produce, baked goods, the locally produced cheese.</p><p><a href="http://wallkillviewfarm.snappages.com/home.htm" target="_blank">wallkillviewfarm.snappages.com/home</a></p>