---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Jenkins.jpg'
title: 'Jenkins & Lueken Orchards'
activity: 'Pick & Grow'
---
<p>You'll be&nbsp;in good company if you visit this orchard to pick or the farm stand to purchase. Jenkins & Luekin Orchards offers&nbsp;vegetables, peaches, plums, raspberries, blackberries, pumpkins, summer and winter squash, fall garden mums, and grapes in&nbsp;pure scenery.&nbsp;</p><p><a href="http://www.jlorchards.com/" target="_blank">jlorchards.com</a></p>