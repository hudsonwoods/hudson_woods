---
title: Catskill Native Nursery
heroImages:
  - 
    headline: ""
    subHeadline: ""
    image: '{{ _site_root }}assets/img/upgrades/Catskill Native Nursery.jpg'
activity: 'Pick & Grow'
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Catskill.jpg'
---
<p>Catskill Native Nursery is the closest garden source to Hudson Woods. It's a&nbsp;comprehensive and beautiful nursery that will guide you to create brilliant gardens. We source our seedlings there, and&nbsp;they source their&nbsp;seeds from our friends at the Hudson Valley Seed Library.</p><p><a href="http://www.catskillnativenursery.com/" target="_blank">catskillnativenursery.com</a></p>