---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Stone_orchard.jpg'
title: Stone Ridge Orchard
activity: 'Pick & Grow'
---
<p>This orchard has been producing apples for over two hundred years. In two major re-plantings, dozens of new gourmet varieties were added on semi-dwarfing or fully dwarfing rootstocks that produce bigger, sweeter and redder fruit. Recently they have started growing&nbsp;sweet cherries, peaches, nectarines, plums and Asian pears.&nbsp;</p><p><a href="http://www.stoneridgeorchard.us/" target="_blank">stoneridgeorchard.us</a></p>