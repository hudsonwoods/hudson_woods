---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Davenport.jpg'
title: Davenport Farms
activity: 'Pick & Grow'
---
<p>The Davenport family has been&nbsp;farming this land&nbsp;since Isaiah Davenport moved across the Hudson River in the 1840s, and a family&nbsp;member&nbsp;can still be found working in every phase of the farm.&nbsp;The farm stand makes baked goods and carries local products while the rather robust nursery has a tons&nbsp;of plant life.</p><p><a href="http://www.davenportfarms.com" target="_blank">davenportfarms.com</a></p>