---
image: '{{ _site_root }}assets/img/makers/Hickman-Lumber-20140805121108.jpg'
logo: '{{ _site_root }}assets/img/makers/HickmanLumberLogoLong.png'
title: Hickman Lumber Co.
makerTitle: Hickman Lumber Co.
makerTagline: 'Locally & ethically sourced high-grade species of Black Cherry, Red & White Oak, & Ash'
link: http://hickmanlumbercompany.com
---
