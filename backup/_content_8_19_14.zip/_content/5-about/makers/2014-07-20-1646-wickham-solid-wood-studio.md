---
image: '{{ _site_root }}assets/img/makers/Jessican-Wikckham.jpg'
title: Wickham Solid Wood Studio
makerTitle: Wickham Solid Wood Studio
makerTagline: Hand-Crafted Furniture from Beacon, NY using responsibly sourced local hardwoods
link: http://jessica-wickham.com/
logo: '{{ _site_root }}assets/img/makers/Wickham-Logo.jpg'
---
