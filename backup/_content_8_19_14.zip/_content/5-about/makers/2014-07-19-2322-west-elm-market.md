---
image: '{{ _site_root }}assets/img/makers/westelmMARKET-20140815105202.jpg'
title: West Elm MARKET
makerTitle: west elm MARKET
makerTagline: 'Shops with focus on functional design, local production, entrepreneurship & community'
link: http://www.westelm.com/stores/us/ny/brooklyn-market-brklyn/
logo: '{{ _site_root }}assets/img/makers/WestElmMarket.jpg'
---
