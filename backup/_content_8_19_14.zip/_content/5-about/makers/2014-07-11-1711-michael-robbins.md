---
image: '{{ _site_root }}assets/img/makers/Michael-Robbins.jpg'
title: Michael Robbins
makerTitle: Michael Robbins
makerTagline: "A furniture studio from New York's Hudson Valley"
link: http://www.mchlrbbns.com/about1/n9tm1q1w0l13ufj9vkavqf9y7v45nu
logo: '{{ _site_root }}assets/img/makers/Michaele-Logo.jpg'
---
