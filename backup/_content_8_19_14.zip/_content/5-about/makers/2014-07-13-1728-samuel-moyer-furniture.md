---
title: Samuel Moyer Furniture
makerTitle: Samuel Moyer Furniture
makerTagline: 'Woodworking studio in Hudson, specializing IN traditional techniques & reclaimed rare woods'
link: http://samuelmoyerfurniture.com/
image: '{{ _site_root }}assets/img/makers/Sam-Moyer-4.jpg'
logo: '{{ _site_root }}assets/img/makers/SamuelMoyer-logo.jpg'
---
