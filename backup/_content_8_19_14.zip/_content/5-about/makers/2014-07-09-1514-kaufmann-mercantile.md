---
image: '{{ _site_root }}assets/img/makers/Kaufmann.png'
title: Kaufmann Mercantile
makerTitle: Kaufmann Mercantile
makerTagline: A collection of goods made with utmost standards in quality
link: http://kaufmann-mercantile.com/
logo: '{{ _site_root }}assets/img/makers/Kauffman-Logo.jpg'
---
